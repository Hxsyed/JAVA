import java.awt.*;

public abstract class Shape3D extends Shape2D {
    
    public final double length
}
