import java.awt.*;

public class Quadrilateral3D extends Shape3D {
}