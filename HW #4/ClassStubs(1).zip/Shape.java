import java.awt.*;

public abstract class Shape implements Comparable<Shape> {

    protected final Integer id;
    protected final String name;
    protected final String description;
    protected Color color;
}