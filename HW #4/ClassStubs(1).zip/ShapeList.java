import java.util.TreeSet;

public class ShapeList extends TreeSet<Shape> {
    
}