import java.awt.*;

public abstract class Shape2D extends Shape {

    public final double height;
    public final double width;
}