import java.awt.*;

public class Quadrilateral extends Shape2D {
}